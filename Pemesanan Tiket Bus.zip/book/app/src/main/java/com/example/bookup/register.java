package com.example.bookup;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.util.Patterns;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.os.Bundle;
import android.widget.Toast;

public class register extends AppCompatActivity {
    TextView textlog;
    EditText editName, createpass, confirmpass, email, phone;
    Button signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        textlog = findViewById(R.id.gtlgn);
        textlog.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(register.this, login.class);
                startActivity(intent);
                finish();
            }
        });
        signup = (Button) findViewById(R.id.regbtn);
        editName = findViewById(R.id.nama);
        createpass = findViewById(R.id.pass);
        confirmpass = findViewById(R.id.confirm);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.nomor);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editName.getText().toString();
                String pass = createpass.getText().toString();
                String confirm = confirmpass.getText().toString();
                String makeemail = email.getText().toString();
                String numb = phone.getText().toString();
                boolean bool = false;
                openlogin();
            }

        });

    }
    public void openlogin(){
        Intent intent = new Intent(this, login.class);
        startActivity(intent);
    }
}
